use SQL_powerBI;
/*Task 1: Identifying Approval Trends*/

/*Q1: Determine the number of drugs approved each year and provide insights into the yearly trends.*/

select distinct(year(DocDate)) as Approved_year,count(year(Docdate)) as Number_of_approvals from appdoc group by year(DocDate) order by Approved_year;
select distinct(year(ActionDate)) as Approved_year,count(year(ActionDate)) as Number_of_approvals from regactiondate group by year(ActionDate) order by Approved_year;

select distinct(year(DocDate)) as Approved_year,(count(year(Docdate))) as Number_of_approvals from appdoc group by year(DocDate) order by  Number_of_approvals DESC limit 1;
select distinct(year(ActionDate)) as Approved_year,(count(year(ActionDate))) as Number_of_approvals from regactiondate group by year(ActionDate) order by  Number_of_approvals DESC Limit 1;

select distinct(year(DocDate)) as Approved_year,(count(year(Docdate))) as Number_of_approvals from appdoc group by year(DocDate) order by  Number_of_approvals  limit 1;
select distinct(year(ActionDate)) as Approved_year,(count(year(ActionDate))) as Number_of_approvals from regactiondate group by year(ActionDate) order by  Number_of_approvals Limit 2;

/*ANS 1: 1. If regactiondate is considered as Year of Approval the approval started from 1939 with number_of_approvals=12 with 2002 having 5736 approvals and 1945 having 5 approvals.
2. If appdoc is considered as Year of Approval the approval started from 1955 with number_of_approvals=1 with 2011 having 3698 approvals and 1955 having 1 approval.*/

/*Q2: Identify the top three years that got the highest and lowest approvals, in descending and ascending order, respectively.*/

select distinct(year(DocDate)) as Approved_year,(count(year(Docdate))) as Number_of_approvals from appdoc group by year(DocDate) order by  Number_of_approvals DESC limit 3;
select distinct(year(ActionDate)) as Approved_year,(count(year(ActionDate))) as Number_of_approvals from regactiondate group by year(ActionDate) order by  Number_of_approvals DESC Limit 3;

select distinct(year(DocDate)) as Approved_year,(count(year(Docdate))) as Number_of_approvals from appdoc group by year(DocDate) order by  Number_of_approvals  limit 3;
select distinct(year(ActionDate)) as Approved_year,(count(year(ActionDate))) as Number_of_approvals from regactiondate group by year(ActionDate) order by  Number_of_approvals Limit 4;

/*Q3: Explore approval trends over the years based on sponsors. */

select Application.sponsorApplicant,count(year(RegActionDate.ActionDate)) ,year(RegActionDate.ActionDate) as year_of_approval from Application 
join RegActionDate on Application.applno=RegActionDate.Applno group by sponsorapplicant, year_of_approval order by sponsorApplicant;

/*Q4: Rank sponsors based on the total number of approvals they received each year between 1939 and 1960.*/

select Application.sponsorApplicant,count(year(RegActionDate.ActionDate)) as Number_of_approval, 
rank() OVER (order by count(year(RegActionDate.ActionDate)) desc) as rank1,
dense_rank() OVER (order by count(year(RegActionDate.ActionDate)) desc) as dense_rank1 
from Application 
join RegActionDate on Application.applno=RegActionDate.Applno
where year(RegActionDate.ActionDate) between 1939 and 1960
group by sponsorapplicant order by Number_of_approval desc;


/*Task 2: Segmentation Analysis Based on Drug MarketingStatus*/


/*1. Group products based on MarketingStatus. Provide meaningful insights into the segmentation patterns.*/

select * From product;
/*Count of different ProductMktStatus*/

select ProductMktStatus,count(ProductMktStatus) FROM product group by ProductMktStatus order by count(ProductMktStatus); 
/*Product form based on different ProductMktStatus */

select form,count(form) as number_of_form_1 from product Where ProductMktStatus=1 group by Form order by number_of_form_1 Desc; 
select form,count(form) as number_of_form_2 from product Where ProductMktStatus=2 group by Form order by number_of_form_2 Desc;
select form,count(form) as number_of_form_3 from product Where ProductMktStatus=3 group by Form order by number_of_form_3 Desc;
select form,count(form) as number_of_form_4 from product Where ProductMktStatus=4 group by Form order by number_of_form_4 Desc; 
 
/*Product active Ingredient based on different ProductMktStatus*/

select activeingred,count(activeingred) as activeingred_1 from product Where ProductMktStatus=1 group by activeingred order by activeingred_1 Desc; 
select activeingred,count(activeingred) as activeingred_2 from product Where ProductMktStatus=2 group by activeingred order by activeingred_2 Desc;
select activeingred,count(activeingred) as activeingred_3 from product Where ProductMktStatus=3 group by activeingred order by activeingred_3 Desc;
select activeingred,count(activeingred) as activeingred_4 from product Where ProductMktStatus=4 group by activeingred order by activeingred_4 Desc; 

/*2. Calculate the total number of applications for each MarketingStatus year-wise after the year 2010.*/

select productmktstatus,Count(sponsorApplicant) as No_of_applicants_after_2010 from(select application.APPlno,sponsorapplicant,productmktstatus from application 
join regactiondate on Application.applno=RegActionDate.Applno 
join product on Application.applno=product.Applno
where year(ActionDate)>2010

) as Merged_Application 
group by productmktstatus;


/*3. Identify the top MarketingStatus with the maximum number of applications and analyze its trend over time.*/


select productmktstatus,Count(sponsorApplicant) as No_of_applicants from(select application.APPlno,sponsorapplicant,productmktstatus from application 
join regactiondate on Application.applno=RegActionDate.Applno 
join product on Application.applno=product.Applno


) as Merged_Application 
group by productmktstatus
order by No_of_applicants desc
limit 1;

/*As we can see that productmktstatus has maximum number of applicants now analysing its trend over time */

select (sponsorapplicant),productmktstatus,year(regactiondate.ActionDate) as _YEAR_ from application 
join regactiondate on Application.applno=RegActionDate.Applno 
join product on Application.applno=product.Applno
where productmktstatus = 1
order by _YEAR_  Desc,sponsorapplicant Asc;

/*As we can see that productmktstatus has maximum number of applicants now analysing its trend over time. */

SELECT YEAR(RegActionDate.ActionDate) AS _YEAR_, COUNT(YEAR(RegActionDate.ActionDate)) AS _COUNT_
FROM Application
JOIN RegActionDate ON Application.applno = RegActionDate.Applno
JOIN Product ON Application.applno = Product.Applno
WHERE Product.productmktstatus = 1
GROUP BY YEAR(RegActionDate.ActionDate)
ORDER BY _YEAR_ DESC, _COUNT_ ASC;


/*Task 3: Analyzing Products */

/*1. Categorize Products by dosage form and analyze their distribution.*/

SELECT drugname, form AS Dosage_form, COUNT(form) as Total_number_of_Dosage
FROM product
GROUP BY drugname, form
order by Total_number_of_Dosage Desc;

/*2. Calculate the total number of approvals for each dosage form and identify the most successful forms */

select form,(ActionType),count(Actiontype) as Total_approval from(
select regactiondate.actiondate,regactiondate.ActionType,application.sponsorApplicant,product.form from regactiondate 
join application on regactiondate.applno=application.applno
join product on regactiondate.applno=product.applno) as merge12
where ActionType = 'AP'
group by form,Actiontype order by Total_approval Desc;

/*Most successful form is oral tablet followed by injectable/injection*/

/*3. Investigate yearly trends related to successful forms. */

select form, ActionType, COUNT(ActionType) as Total_approval,year
from (
select 
regactiondate.actiondate,
regactiondate.ActionType,
application.sponsorApplicant,
product.form,
EXTRACT(YEAR FROM regactiondate.actiondate) AS year
from regactiondate 
Join application ON regactiondate.applno = application.applno
Join product ON regactiondate.applno = product.applno
) AS merge12
Where ActionType = 'AP'
Group by form, ActionType, year
order by Total_approval desc,year Asc;

/*Task 4: Exploring Therapeutic Classes and Approval Trends */

/*1. Analyze drug approvals based on therapeutic evaluation code (TE_Code).*/

select drugname,ActionType,tecode,count(tecode) as No_of_approval_tecode from(

select product.drugname,application.ActionType,product_tecode.tecode from application
join product on application.applno=product.applno
join product_tecode on application.applno=product_tecode.applno
join regactiondate on application.applno=regactiondate.applno
where application.ActionType='AP') as tecode_table
group by drugname,tecode
order by No_of_approval_tecode desc;

/*2. Determine the therapeutic evaluation code (TE_Code) with the highest number of Approvals in each year.*/

select tecode,year(actiondate) as _YEAR_,count(year(actiondate)) as No_of_approvals from (

select product.drugname,application.ActionType,product_tecode.tecode,regactiondate.actiondate from application
join product on application.applno=product.applno
join product_tecode on application.applno=product_tecode.applno
join regactiondate on application.applno=regactiondate.applno
where application.ActionType='AP') as Approvals_analysis
group by tecode,_YEAR_
order by _YEAR_,No_of_approvals Desc;


